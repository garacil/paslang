SELECT hex(printf('%!.2s', CAST(x'3f9fc020bf' AS TEXT))), hex(printf('%!.1s', CAST(x'6180' AS TEXT)));

PRAGMA encoding = 'UTF-16le';
SELECT '3' + 0, typeof('3' + 0), '1x' + 0, '9007199254740993' + 0, CAST(x'3165f0ffe2' AS TEXT) + 0;
